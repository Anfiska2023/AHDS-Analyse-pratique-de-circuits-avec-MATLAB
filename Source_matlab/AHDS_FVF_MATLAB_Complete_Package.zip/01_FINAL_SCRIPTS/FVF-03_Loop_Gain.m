% AHDS FVF-03 — RETURN RATIO, POLES, ZEROS AND STABILITY
% AHDS — Anissoff Hardware Development System
% Design once. Reuse forever. | ahds@engineer.com
% MATLAB Online / base MATLAB (no Control System Toolbox required).
%
% MODEL AND INTERPRETATION
% PMOS MP: source at AC-grounded VDD, gate F, drain Vout.
% PMOS MF: source Vout, gate Vin (AC grounded for return-ratio test), drain F.
% CgdP connects gate F and drain Vout (MUST remain connected).
% Cc shunts F; Cout shunts Vout; roB shunts F to ground.
% This program calculates the RETURN RATIO of MP's gm-controlled source
% using a rank-one loop interruption, NOT a naive open-circuit at the gate.
% Since Cgd is a bidirectional path, an ideal physical gate-wire break
% can change the loading and need not measure the same return ratio.
%
% M(s) = G + s*C = M0(s) + gmP*[1;0]*[0,1];
% L(s) = gmP*[0,1]*(M0(s)\[1;0]).
% det(M(s)) = det(M0(s))*(1+L(s)); this identity is verified below.
% Feedback convention: closed-loop characteristic equation is 1+L(s)=0.
%
% PRELIMINARY: device gm, ro, Cgd are illustrative placeholders from V3.
% No DC operating point, nonlinear C(V), parasitic Cgs, device SOA,
% frequency-dependent gm or hardware behaviour has been validated.
% The calculated PM/GM describe THIS return ratio at this linearization.

clear; clc; close all;              % Start reproducible run; clear figures.

%% A. Shared engineering assumptions — kept identical to AHDS FVF V3.1
Cc = 100e-12;                     % [F] F node capacitor.
Cout = 5e-12;                    % [F] output load capacitance.
roB = 200e3;                     % [ohm] bias-source output resistance.
gmF = 5e-3;                      % [S] MF transconductance.
roF = 100e3;                     % [ohm] MF output resistance.
frequencies = logspace(0,12,5001)'; % [Hz] from 1 Hz to 1 THz; model only.
withCgdCases = [true false];     % Compare included Cgd with Cgd=0.

%% B. All three MP options (only ONE installed per evaluation)
devices = struct( ...
 'name',{'BSS84','IRF9540N','IRF4905'}, ...
 'gmP',{3e-3,80e-3,150e-3}, ...   % [S] MP gm, assumed.
 'roP',{80e3,20e3,12e3}, ...      % [ohm] MP ro, assumed.
 'CgdP',{3e-12,240e-12,500e-12}); % [F] assumed CgdP.

%% C. Storage for one-row summaries and frequency response exports
summaryRows = {};                % One row for each device/Cgd variant.
curveRows = {};                  % Retain numerical complex frequency data.
rootRows = {};                   % One row per pole or zero.

for di = 1:numel(devices)        % Evaluate each candidate transistor.
    D = devices(di);             % Pick current device record.
    for ci = 1:numel(withCgdCases) % Two capacitance variants.
        Cgd = D.CgdP*double(withCgdCases(ci)); % [F] selected capacitance.
        mode = 'WithCgd';         % Descriptive tag for figure and CSV.
        if Cgd == 0, mode = 'NoCgd'; end % Control experiment Cgd=0.
        tag = [D.name '_' mode];  % Noncolliding file identifier.

        %% D. Build 2x2 NODAL MATRICES with Vin held at AC ground.
        gop = 1/D.roP;           % [S] conductance of MP output resistance.
        gof = 1/roF;             % [S] conductance of MF output resistance.
        gob = 1/roB;             % [S] bias branch leakage conductance.
        C = [Cout+Cgd, -Cgd; -Cgd, Cc+Cgd]; % Dynamic matrix incl Cgd.
        G0 = [gop+gmF+gof, -gof; -(gmF+gof), gof+gob]; % gmP absent.
        e1 = [1;0];              % Inject controlled current at Vout row.
        e2 = [0;1];              % Read sensed gate voltage at node F.
        Gcl = G0 + D.gmP*(e1*e2.'); % Restore gmP to close the loop.

        %% E. Return ratio L(s) = N(s)/D(s), computed analytically.
        % det(G0+sC) = a2*s^2 + a1*s + a0.
        a2 = det(C);             % [F^2] quadratic determinant term.
        a1 = G0(1,1)*C(2,2)+C(1,1)*G0(2,2) ...
             -G0(1,2)*C(2,1)-C(1,2)*G0(2,1); % Linear determinant term.
        a0 = det(G0);            % [S^2] constant determinant term.
        % [M0^-1]21 = -M0(2,1)/det(M0).
        % -M0(2,1) = (gmF+gof) + s*Cgd.
        b1 = D.gmP*Cgd;         % [S*F] first-order numerator coefficient.
        b0 = D.gmP*(gmF+gof);  % [S^2] constant numerator coefficient.
        den = [a2 a1 a0];       % Open gmP-controlled-path determinant.
        num = [b1 b0];          % Return-ratio numerator with Cgd zero.
        openPoles = roots(den);  % [rad/s] RETURN-RATIO poles, not H poles.
        loopZeros = [];         % Empty for constant numerator (Cgd=0).
        if b1 ~= 0              % Nonzero Cgd makes one finite zero.
            loopZeros = -b0/b1; % [rad/s], always LHP for positive params.
        end
        closedPoles = roots([a2 a1+b1 a0+b0]); % [rad/s], 1+L char.

        %% F. Numerically verify the determinant identity at test points.
        maxResidual = 0;        % Max relative error of loop identity.
        for fcheck = [1e2 1e5 1e8] % Three independent test frequencies.
            s = 1i*2*pi*fcheck;  % Complex Laplace variable [rad/s].
            M0 = G0+s*C;         % Nodal matrix with gmP source removed.
            Mcl = Gcl+s*C;       % Nodal matrix with gmP source restored.
            Ldirect = D.gmP*(e2.'*(M0\e1)); % Direct nodal return ratio.
            Lpoly = (b1*s+b0)/(a2*s^2+a1*s+a0); % Polynomial form.
            residual = abs(Ldirect-Lpoly)/max(1,abs(Ldirect));
            maxResidual = max(maxResidual,residual); % Track discrepancy.
            identityResidual = abs(det(Mcl)-det(M0)*(1+Ldirect)) ...
                /max(abs(det(Mcl)),realmin); % Relative det mismatch.
            maxResidual = max(maxResidual,identityResidual);
        end
        assert(maxResidual<1e-6,'Return-ratio identity failed for %s',tag);

        %% G. Complex return ratio across frequency (not closed-loop gain).
        s = 1i*2*pi*frequencies; % Evaluate jw for all frequencies.
        L = (b1*s+b0)./(a2*s.^2+a1*s+a0); % True gmP-path L(jw).
        gainDB = 20*log10(abs(L)); % [dB] loop-gain magnitude.
        phaseDeg = unwrap(angle(L))*180/pi; % [deg] continuous phase.

        %% H. Compute gain/phase margins only at ACTUAL crossings.
        % Phase margin at each |L|=1 crossing; multiple -> minimum PM.
        ixGC = find((gainDB(1:end-1).*gainDB(2:end)<=0) ...
              & (gainDB(1:end-1)~=gainDB(2:end))); % Gain cross indices.
        gainCrossHz = NaN; phaseMargin = NaN; % Undefined if none found.
        if ~isempty(ixGC)       % At least one gain crossover exists.
            pmSet = []; fcSet = []; % Store all possible crossings.
            for k=ixGC.'        % Interpolate each 0-dB crossing in log f.
                r = -gainDB(k)/(gainDB(k+1)-gainDB(k)); % Linear dB fraction.
                fc = 10^(log10(frequencies(k)) + r* ...
                    (log10(frequencies(k+1))-log10(frequencies(k))));
                pc = phaseDeg(k)+r*(phaseDeg(k+1)-phaseDeg(k));
                pmSet(end+1) = 180+pc; %#ok<SAGROW> % PM for 1+L convention.
                fcSet(end+1) = fc; %#ok<SAGROW> % Corresponding frequency.
            end
            [phaseMargin,ii] = min(pmSet); % Conservative minimum reported.
            gainCrossHz = fcSet(ii);  % Associated unity crossover.
        end
        % Gain margin at each phase = -(180 + 360*k) degrees.
        gainMarginDB = Inf; phaseCrossHz = NaN; % No crossing -> Inf GM.
        phaseTargets = -180-360*(0:10); % Relevant negative crossings.
        for ph=phaseTargets     % Search phase crossing candidates.
            ixPC = find((phaseDeg(1:end-1)-ph).* ...
                (phaseDeg(2:end)-ph)<=0 & ...
                phaseDeg(1:end-1)~=phaseDeg(2:end));
            for k=ixPC.'        % Interpolate at each phase crossing.
                r=(ph-phaseDeg(k))/(phaseDeg(k+1)-phaseDeg(k));
                gd=gainDB(k)+r*(gainDB(k+1)-gainDB(k));
                candidate=-gd;  % GM [dB] = -gain at phase crossover.
                if candidate<gainMarginDB % Select minimum gain margin.
                    gainMarginDB=candidate; % Store worst-case GM.
                    phaseCrossHz=10^(log10(frequencies(k))+r* ...
                      (log10(frequencies(k+1))-log10(frequencies(k))));
                end
            end
        end
        if ~isfinite(gainMarginDB) % No -180 crossing in chosen sweep.
            fprintf('No -180 degree crossover between %.3g and %.3g Hz.\n', ...
                frequencies(1),frequencies(end));
        end

        %% I. Print and save mathematically distinct pole sets.
        fprintf('\n=== %s | %s: gmP CONTROLLED-PATH RETURN RATIO ===\n', ...
            D.name,mode);
        fprintf('L(0) = %.8g (%.5f dB)\n',b0/a0,20*log10(abs(b0/a0)));
        fprintf('Return-ratio poles [Hz]: %s\n',mat2str(openPoles.'/(2*pi),7));
        if isempty(loopZeros)
            fprintf('Return-ratio zeros: NO FINITE ZERO in this order.\n');
        else
            fprintf('Return-ratio zero [Hz]: %s\n', ...
                mat2str(loopZeros.'/(2*pi),7));
        end
        fprintf('Closed-loop poles [Hz]: %s\n',mat2str(closedPoles.'/(2*pi),7));
        fprintf('Gain crossover [Hz] = %.8g; PM [deg] = %.6g\n', ...
            gainCrossHz,phaseMargin);
        fprintf('Phase crossover [Hz] = %.8g; GM [dB] = %.6g\n', ...
            phaseCrossHz,gainMarginDB);
        fprintf('Matrix identity relative error: %.4g\n',maxResidual);

        if any(real(closedPoles)>=0) % Evaluate stability independently.
            stability='UNSTABLE'; % Right-half-plane closed-loop pole.
        else
            stability='Stable in this linear model'; % All LHP poles.
        end
        summaryRows(end+1,:)={D.name,mode,Cgd*1e12, ...
            b0/a0,gainCrossHz,phaseMargin,phaseCrossHz,gainMarginDB,...
            stability,maxResidual}; %#ok<SAGROW>
        for j=1:numel(openPoles) % Export all finite loop poles.
            rootRows(end+1,:)={D.name,mode,'Loop pole', ...
                real(openPoles(j))/(2*pi),imag(openPoles(j))/(2*pi)}; %#ok<SAGROW>
        end
        for j=1:numel(loopZeros) % Export each finite return-ratio zero.
            rootRows(end+1,:)={D.name,mode,'Loop zero', ...
                real(loopZeros(j))/(2*pi),imag(loopZeros(j))/(2*pi)}; %#ok<SAGROW>
        end
        for j=1:numel(closedPoles) % Export closed-loop poles separately.
            rootRows(end+1,:)={D.name,mode,'Closed-loop pole', ...
                real(closedPoles(j))/(2*pi),imag(closedPoles(j))/(2*pi)}; %#ok<SAGROW>
        end
        for j=1:numel(frequencies) % Preserve complete Bode numeric data.
            curveRows(end+1,:)={D.name,mode,frequencies(j), ...
                real(L(j)),imag(L(j)),gainDB(j),phaseDeg(j)}; %#ok<SAGROW>
        end

        %% J. Separate numbered figures that remain open after simulation.
        fig=figure('Color','w','Name',['AHDS FVF-03 ' tag ' Return Ratio']);
        subplot(2,1,1);          % First panel: loop return magnitude.
        semilogx(frequencies,gainDB,'LineWidth',1.4); hold on;
        yline(0,'--'); grid on; ylabel('|L| [dB]');
        title([tag ' | gmP-path return ratio (NOT closed-loop H)']);
        if isfinite(gainCrossHz), xline(gainCrossHz,':'); end
        subplot(2,1,2);          % Second panel: loop return phase.
        semilogx(frequencies,phaseDeg,'LineWidth',1.4); hold on;
        yline(-180,'--'); grid on; xlabel('Frequency [Hz]');
        ylabel('Phase [degrees]');
        saveas(fig,['AHDS_FVF03_' tag '_Bode.png']); % Save and KEEP figure.
    end
end

%% K. Compact comparison figure of all 6 return-ratio variants.
figCompare=figure('Color','w','Name','AHDS FVF-03 all loop gains');
subplot(2,1,1); hold on; grid on; % Overlay loop gain magnitudes.
subplot(2,1,2); hold on; grid on; % Overlay loop gain phases.
labels={};                      % Descriptive legend labels.
for di=1:numel(devices)          % Iterate all three MOSFET variants.
    for ci=1:2                  % With Cgd and Cgd=0.
        mode='WithCgd'; if ci==2,mode='NoCgd';end
        ix=strcmp(curveRows(:,1),devices(di).name) ...
           & strcmp(curveRows(:,2),mode); % Rows for one variant.
        x=cell2mat(curveRows(ix,3));       % Frequency from saved rows.
        ydb=cell2mat(curveRows(ix,6));     % Magnitude in decibels.
        yp=cell2mat(curveRows(ix,7));      % Unwrapped phase.
        subplot(2,1,1); semilogx(x,ydb,'LineWidth',1);
        subplot(2,1,2); semilogx(x,yp,'LineWidth',1);
        labels{end+1}=[devices(di).name ' ' mode]; %#ok<SAGROW>
    end
end
subplot(2,1,1); yline(0,'--'); ylabel('|L| [dB]');
title('AHDS FVF-03 return-ratio magnitude comparison');
legend(labels,'Location','best');
subplot(2,1,2); yline(-180,'--'); ylabel('Phase [deg]');
xlabel('Frequency [Hz]');
legend(labels,'Location','best');
saveas(figCompare,'AHDS_FVF03_All_Devices_Comparison.png');

%% L. Results tables; no toolbox and no external helper functions.
Summary=cell2table(summaryRows,'VariableNames', ...
 {'MOSFET','CgdCase','Cgd_pF','DC_Return_Ratio', 'GainCross_Hz', ...
  'PhaseMargin_deg','PhaseCross_Hz','GainMargin_dB','ClosedLoopStatus', ...
  'DeterminantResidual'});
Roots=cell2table(rootRows,'VariableNames', ...
 {'MOSFET','CgdCase','RootType','Real_Hz','Imag_Hz'});
BodeData=cell2table(curveRows,'VariableNames', ...
 {'MOSFET','CgdCase','Frequency_Hz','LoopReal','LoopImag', ...
  'Gain_dB','Phase_deg'});
disp('=== AHDS FVF-03 — RETURN-RATIO MARGINS ==='); disp(Summary);
disp('=== AHDS FVF-03 — ALL POLES AND ZEROS ==='); disp(Roots);
writetable(Summary,'AHDS_FVF03_Stability_Summary.csv');
writetable(Roots,'AHDS_FVF03_Poles_Zeros.csv');
writetable(BodeData,'AHDS_FVF03_Bode_Data.csv');
fprintf('\nSaved 7 PNG figures + 3 CSV tables. All 7 figures stay open.\n');
fprintf('This analysis uses illustrative linearized parameters, not hardware data.\n');
fprintf('The gmP-source return ratio preserves Cgd; NOT a loaded gate-break test.\n');
