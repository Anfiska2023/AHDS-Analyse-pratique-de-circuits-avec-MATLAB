% AHDS FVF-04 — GATE-BREAK LOADING VERIFICATION
% AHDS — Anissoff Hardware Development System | ahds@engineer.com
% MATLAB Online, BASE MATLAB ONLY. All parameters are illustrative.
%
% OBJECTIVE
% 1. Split the original F node and MP gate G, preserving MP Cgd (G to OUT).
% 2. Insert an ideal SERIES VOLTAGE TEST SOURCE V(G)-V(F)=U.
% 3. Verify that reconnecting the gate (U=0) reproduces exactly the
%    ORIGINAL closed-circuit nodal matrix, even with bilateral Cgd.
% 4. Compare an open-gate voltage-return experiment with the previously
%    calculated gmP-source return ratio of AHDS FVF-03.
%
% IMPORTANT LIMITATION: The open-gate voltage-return response is NOT a
% loaded, bilateral, invariant loop gain / return ratio. It does NOT by
% itself define a valid phase margin or gain margin of the intact FVF.
% A truly invariant multi-path loop analysis requires a defined two-port
% probe and a suitable combined voltage/current injection technique.
% No such equivalence is claimed here. FVF-03 remains a defined gmP-path
% return ratio. This study diagnoses why a plain gate break differs.
%
% TOPOLOGY: PMOS MP source = AC ground VDD, drain OUT, gate G.
% PMOS MF source OUT, gate VIN=AC ground, drain feedback node F.
% F-to-ground: Cc and roB; OUT-to-ground: Cout; MP Cgd = G-to-OUT.
% Only one MP candidate is installed for a given simulation.
%
clear; clc; close all;

%% 1. Shared reference model (identical to V3.1 and FVF-03)
Cc = 100e-12;                      % Feedback-node capacitance [F].
Cout = 5e-12;                     % Output load capacitance [F].
roB = 200e3;                      % Bias current source resistance [ohm].
gmF = 5e-3;                       % MF transconductance [S].
roF = 100e3;                      % MF output resistance [ohm].
gof = 1/roF; gob = 1/roB;        % MF and bias conductances [S].
freq = logspace(1,10,1601)';     % Sweep in Hz; model is not valid to 10 GHz physically.
samples = [1e3,1e6,1e8];          % Frequency points for identity check [Hz].
D = struct('name',{'BSS84','IRF9540N','IRF4905'}, ...
           'gmP',{3e-3,80e-3,150e-3}, ...
           'roP',{80e3,20e3,12e3}, ...
           'CgdP',{3e-12,240e-12,500e-12});
cases = [1 0];                   % With Cgd / deliberately remove Cgd.
summary = cell(0,8); curves = cell(0,8);

%% 2. One separate figure per MOSFET, two cases overlaid
for di=1:numel(D)
    part=D(di); gop=1/part.roP;
    fig=figure('Color','w','Name',['AHDS FVF-04 ' part.name ' gate break']);
    for ci=1:numel(cases)
        Cgd=cases(ci)*part.CgdP;
        label='WithCgd'; if Cgd==0, label='NoCgd'; end
        gateReturn=zeros(size(freq)); gmReturn=zeros(size(freq));
        testImpedance=zeros(size(freq));
        errMax=0;

        %% 3. Construct SPLIT-GATE Modified Nodal Analysis matrix.
        % Unknowns are [Vout; Vf; Vg; Itest]. Itest is series-source
        % current flowing out of node F into G by the selected sign.
        % Equation 4 is Vg - Vf = Utest.
        % Gate KCL contains -s*Cgd*Vout + s*Cgd*Vg - Itest = 0.
        % Thus Cgd remains connected even when the gate wire is cut.
        for k=1:numel(freq)
            s=1i*2*pi*freq(k);
            Msplit=[gop+gmF+gof+s*(Cout+Cgd), -gof, part.gmP-s*Cgd, 0; ...
                    -(gmF+gof), gof+gob+s*Cc, 0, 1; ...
                    -s*Cgd, 0, s*Cgd, -1; ...
                     0, -1, 1, 0];

            % A SERIES test voltage of 1 V across the F-to-G break.
            % Source current and all node voltages follow the loaded MNA.
            x=Msplit\[0;0;0;1];
            % The test-port impedance is source voltage / source current.
            % Sign of current depends on voltage-source orientation.
            testImpedance(k)=1/x(4);

            % Open-gate VOLTAGE injection: set Vg = 1 while the F-G wire
            % remains open; the gate capacitance Cgd loads OUT but its
            % current is supplied by the ideal stimulus, not by node F.
            % This is a diagnostic voltage-return experiment, NOT the
            % invariant loop gain of the original intact circuit.
            A=[gop+gmF+gof+s*(Cout+Cgd), -gof; ...
               -(gmF+gof),gof+gob+s*Cc];
            y=A\[s*Cgd-part.gmP;0];
            gateReturn(k)=-y(2); % -Vf/Vg, with Vg=1.

            % Previously reported gmP controlled-source return ratio.
            % It retains the ORIGINAL F/G-tied Cgd and disconnects gmP.
            Cfull=[Cout+Cgd,-Cgd;-Cgd,Cc+Cgd];
            G0=[gop+gmF+gof,-gof;-(gmF+gof),gof+gob];
            gmReturn(k)=part.gmP*([0 1]*((G0+s*Cfull)\[1;0]));
        end

        %% 4. Definitive consistency test: zero insertion voltage = short.
        % Excite OUT with 1 uA to produce nonzero node voltages, then
        % demand Vg=Vf. Compare with ORIGINAL 2-node closed matrix.
        for fc=samples
            s=1i*2*pi*fc;
            Msplit=[gop+gmF+gof+s*(Cout+Cgd),-gof,part.gmP-s*Cgd,0; ...
                -(gmF+gof),gof+gob+s*Cc,0,1; ...
                -s*Cgd,0,s*Cgd,-1;0,-1,1,0];
            xs=Msplit\[1e-6;0;0;0]; % Shorted F-G gate, 1-uA OUT test.
            Gcl=[gop+gmF+gof,part.gmP-gof; ...
                 -(gmF+gof),gof+gob];
            Ccl=[Cout+Cgd,-Cgd;-Cgd,Cc+Cgd];
            xc=(Gcl+s*Ccl)\[1e-6;0];
            resid=norm(xs(1:2)-xc)/max(norm(xc),realmin);
            gateMismatch=abs(xs(3)-xs(2))/max(norm(xc),realmin);
            errMax=max([errMax,resid,gateMismatch]);
        end
        assert(errMax<1e-7,'Closed topology mismatch for %s %s',part.name,label);

        %% 5. Plot and export all frequency data.
        subplot(2,1,1); hold on; grid on;
        semilogx(freq,20*log10(abs(gateReturn)),'LineWidth',1.3, ...
            'DisplayName',[label ': gate voltage return']);
        semilogx(freq,20*log10(abs(gmReturn)),'--','LineWidth',1.1, ...
            'DisplayName',[label ': gmP source return']);
        ylabel('Return magnitude [dB]');
        title([part.name ' | two DIFFERENT loop experiments']);
        subplot(2,1,2); hold on; grid on;
        semilogx(freq,unwrap(angle(gateReturn))*180/pi,'LineWidth',1.3, ...
            'DisplayName',[label ': gate voltage return']);
        semilogx(freq,unwrap(angle(gmReturn))*180/pi,'--','LineWidth',1.1, ...
            'DisplayName',[label ': gmP source return']);
        xlabel('Frequency [Hz]'); ylabel('Phase [degrees]');
        fidx=find(freq>=1e6,1);
        fprintf('\n%s | %s | DC gate return %.6g | DC gmP return %.6g\n',...
            part.name,label,real(gateReturn(1)),real(gmReturn(1)));
        fprintf('At %.3g Hz: gate-return %.3f dB, gmP-return %.3f dB\n',...
            freq(fidx),20*log10(abs(gateReturn(fidx))),...
            20*log10(abs(gmReturn(fidx))));
        fprintf('Zero-source-voltage short reconstruction residual: %.3e\n',errMax);
        summary(end+1,:)={part.name,label,Cgd*1e12, ...
            real(gateReturn(1)),real(gmReturn(1)),...
            20*log10(abs(gateReturn(fidx))),...
            20*log10(abs(gmReturn(fidx))),errMax}; %#ok<SAGROW>
        for k=1:numel(freq)
            curves(end+1,:)={part.name,label,freq(k), ...
                real(gateReturn(k)),imag(gateReturn(k)), ...
                real(gmReturn(k)),imag(gmReturn(k)),abs(testImpedance(k))}; %#ok<SAGROW>
        end
    end
    subplot(2,1,1); legend('Location','best');
    subplot(2,1,2); legend('Location','best');
    saveas(fig,['AHDS_FVF04_' part.name '_GateBreak.png']);
end

%% 6. Save tables for use in the final AHDS publication.
Summary=cell2table(summary,'VariableNames',{'MOSFET','Mode','Cgd_pF', ...
    'GateReturnNearDC','GmPathReturnNearDC','GateReturn_1MHz_dB',...
    'GmPathReturn_1MHz_dB','ShortReconstructionError'});
Curves=cell2table(curves,'VariableNames',{'MOSFET','Mode','Frequency_Hz',...
    'GateReturnReal','GateReturnImag','GmPathReturnReal',...
    'GmPathReturnImag','BreakPortZMagnitude_ohm'});
writetable(Summary,'AHDS_FVF04_Summary.csv');
writetable(Curves,'AHDS_FVF04_Curves.csv');
disp(' '); disp('=== AHDS FVF-04 GATE-BREAK COMPARISON ===');
disp(Summary);
fprintf('\nSaved 3 PNG figures + 2 CSV tables. Figures remain open.\n');
fprintf(['Interpretation: the ZERO-volt series probe recovers the original ' ...
    'loaded circuit.\nA plain OPEN-GATE voltage gain is not the same ' ...
    'invariant return ratio as the gmP-path method.\n']);
fprintf(['No physical MOSFET is validated; parameters are ' ...
    'illustrative and frequency range exceeds model bandwidth.\n']);
