% AHDS MATLAB-01 / MATLAB-02 | FVF FREQUENCY SWEEP — VERSION 3
% Anissoff Hardware Development System | Design once. Reuse forever.
% Email: ahds@engineer.com | MATLAB Online | BASE MATLAB ONLY.
% Every stage is documented so readers can reproduce the analysis.
%
% CAUTION — ILLUSTRATIVE LINEARIZATION, NOT A VALIDATED SPICE MODEL:
%  gm, ro, Cgd, Cc and Cout are assumptions, NOT extracted device values.
%  No nonlinear DC operating point, VGS limits, power dissipation, thermal
%  behaviour or physical hardware has been validated.
%  Poles below are CLOSED-LOOP poles, NOT return-ratio/loop-gain poles.
%  The 0-Cgd case is a controlled sensitivity experiment, not a real MOSFET.
%  No Control System Toolbox / Signal Processing Toolbox is needed.
%
% Circuit: PMOS MP source = VDD(AC ground), gate = F, drain = Vout;
% PMOS MF source = Vout, gate = Vin, drain = F; Cc from F to ground;
% Cout from Vout to ground; CgdP bridges F and Vout; roB from F to ground.
clear; clc; close all;  % Clear workspace, reset console and close figures.

%% A. Choose the experiment (the four frequencies are common to both files)
VDD = 12;                    % [V] illustrative supply (not DC-validated).
Vbias = 6;                   % [V] nominal bias reference (not solved).
inputPeak = 50e-3;           % [V] small-signal excursion +/-50 mV.
freqList = [1e3 1e4 1e5 1e6]; % [Hz] four fundamental test frequencies.
includeCgd = [true false];   % Sensitivity: actual assumed Cgd, and zero Cgd.
Cc = 100e-12;                % [F] node F compensation capacitor.
Cout = 5e-12;               % [F] output capacitor.
roB = 200e3;                % [ohm] nonideal bias-current source resistance.
gmF = 5e-3;                 % [S] fixed follower MOSFET MF, illustrative.
roF = 100e3;                % [ohm] fixed follower MOSFET MF, illustrative.
numHarmonics = 101;         % Number of ODD harmonics for triangle synthesis.
% Sine is calculated from the exact complex frequency response.
% Square is calculated from the exact two-state periodic solution.
% Triangle uses a 101-odd-harmonic steady-state Fourier approximation.

%% B. Alternative transistor choices for MP (NOT simultaneously in circuit)
devices = struct('name',{'BSS84 (small signal)'}, ...
    'tag',{'BSS84'},'gmP',{3e-3},'roP',{80e3},'CgdP',{3e-12});
% Device values are placeholders from V2, not vendor-validated.

%% C. Empty tables to collect all device/frequency/capacitance results.
rows = {};                   % One summary row per waveform per test case.
edgeRows = {};               % One edge row per device and Cgd case.
frequencyRows = {};          % Complex response, gain, phase per frequency.
waveNames = {'Sine','Square','Triangle'}; % Display and CSV identifiers.

for d = 1:numel(devices)     % Iterate over selected MOSFET substitutions.
    D = devices(d);          % Current MOSFET parameter record.
    for capCase = 1:2       % First with Cgd, second with Cgd set to zero.
        withCgd = includeCgd(capCase);  % Boolean for the current test.
        CgdP = double(withCgd)*D.CgdP; % [F] set exactly zero for control.
        capLabel = 'WithCgd';          % Label that identifies Cgd present.
        if ~withCgd, capLabel = 'NoCgd'; end % Label for removal experiment.
        tag = [D.tag '_' capLabel];    % Unique file suffix, avoids overwrite.

        %% D. Small-signal nodal matrices: C dx/dt + Gx = Bu.
        gop = 1/D.roP;        % [S] MP output conductance.
        gof = 1/roF;         % [S] MF output conductance.
        gob = 1/roB;         % [S] bias-source conductance.
        C = [Cout+CgdP, -CgdP; -CgdP, Cc+CgdP]; % Nodal capacitances.
        G = [gop+gmF+gof, D.gmP-gof; -(gmF+gof), gof+gob]; % Conductance.
        B = [gmF;-gmF];      % Input Vin coupling at the two nodes.
        A = -(C\G);          % State transition matrix in reciprocal seconds.
        Kdc = G\B;           % Steady-state state / input gain vector.
        eigA = eig(A);       % Closed-loop state eigenvalues in rad/s.
        if any(real(eigA)>=0) % Frequency response assumes stable operation.
            error('Unstable illustrative model: %s %s',D.tag,capLabel);
        end
        tauSlow = -1/max(real(eigA)); % [s] longest positive decay constant.
        fprintf('\n=== %s | %s ===\n',D.name,capLabel);
        fprintf('Closed-loop poles [Hz]: %s\n',mat2str(eigA.'/(2*pi),7));
        fprintf('DC incremental Vout/Vin: %.9g\n',Kdc(1));

        %% E. Exact small-signal frequency response H(jw) (NO toolbox).
        H = zeros(numel(freqList),1); % Complex gains, one per frequency.
        for fi=1:numel(freqList)      % Evaluate all four frequencies.
            omega = 2*pi*freqList(fi); % [rad/s] current angular frequency.
            state = (G+1i*omega*C)\B; % Nodal AC solution at j*omega.
            H(fi) = state(1);         % Complex Vout / Vin.
            frequencyRows(end+1,:) = {D.name,capLabel,freqList(fi), ...
                abs(H(fi)),20*log10(abs(H(fi))),angle(H(fi))*180/pi}; %#ok<SAGROW>
        end

        %% F. Exact linear step response and edge metrics (no coarse grid).
        step_t = linspace(0,max(12*tauSlow,1e-9),4001)'; % Dense edge axis.
        step_y = localStepOutput(A,Kdc,inputPeak,step_t); % Analytic step.
        finalLow = -Kdc(1)*inputPeak; % [V] settled LOW output.
        finalHigh = Kdc(1)*inputPeak; % [V] settled HIGH output.
        normalized = (step_y-finalLow)/(finalHigh-finalLow); % 0 -> 1.
        rt10 = localCross(step_t,normalized,0.1); % [s] first 10% crossing.
        rt90 = localCross(step_t,normalized,0.9); % [s] first 90% crossing.
        rt50 = localCross(step_t,normalized,0.5); % [s] first 50% crossing.
        rise_ns = (rt90-rt10)*1e9; % [ns] 10%-to-90% rise time.
        delay_ns = rt50*1e9;       % [ns] 50% propagation from input edge.
        overshoot = max(0,(max(normalized)-1)*100); % [%] beyond final.
        undershoot = max(0,-min(normalized)*100);   % [%] below initial.
        lastBad = find(abs(normalized-1)>0.02,1,'last'); % Last 2% breach.
        settle_ns = 0;             % [ns] default if immediately settled.
        if ~isempty(lastBad), settle_ns=step_t(lastBad)*1e9; end
        % Falling edge has equal 90-to-10 time ONLY in this linear model.
        edgeRows(end+1,:)={D.name,capLabel,rise_ns,rise_ns,delay_ns,...
            overshoot,undershoot,settle_ns}; %#ok<SAGROW>
        fprintf('Edge rise %.3f ns | delay %.3f ns | settle %.3f ns\n',...
            rise_ns,delay_ns,settle_ns);

        ef=figure('Color','w','Name',[tag ' edge']); % Create edge zoom.
        plot(step_t*1e9,step_y*1e3,'LineWidth',1.3); hold on; % Output.
        plot(step_t*1e9,finalHigh*1e3+zeros(size(step_t)),'--'); % Final.
        xlabel('Time after input step [ns]'); ylabel('AC Vout [mV]');
        title([D.tag ' ' capLabel ' | exact small-signal step']);
        legend('Vout','Final Vout','Location','best'); grid on;
        saveas(ef,['AHDS_FVF_V3_BSS84_' tag '_Edge.png']); close(ef);

        %% G. One figure (3 waveforms x 4 frequencies) per model / Cgd.
        wf=figure('Color','w','Name',[tag ' V3 waveforms']); % Grid figure.
        for fi=1:numel(freqList) % Iterate each fundamental frequency.
            f=freqList(fi);       % [Hz] selected fundamental frequency.
            T=1/f;                % [s] period.
            half=T/2;             % [s] ideal square-wave half-period.
            % Adaptive samples: uniform coverage PLUS clustered edges.
            % This resolves nanosecond changes even in a 1 kHz period.
            tUniform=linspace(0,T,1601)'; % Main waveform time mesh.
            tEdge=logspace(log10(max(1e-13,tauSlow/1000)),...
                log10(min(15*tauSlow,T/4)),260)'; % Near-edge mesh.
            t=unique([tUniform;tEdge;half+tEdge;T-tEdge]); % Combined mesh.
            t=t(t>=0 & t<=T); % Keep exactly one fundamental period.
            theta=2*pi*f*t;   % [rad] input fundamental phase.
            U=zeros(numel(t),3); % Columns: sine, square, triangle.
            U(:,1)=inputPeak*sin(theta); % Sine input waveform.
            U(:,2)=inputPeak*(2*(t<half)-1); % Exact periodic square input.
            U(:,3)=inputPeak*(2/pi)*asin(sin(theta)); % Exact triangle input.
            Y=zeros(numel(t),3); % Model response waveform columns.
            Y(:,1)=inputPeak*imag(H(fi)*exp(1i*theta)); % Exact sine phasor.
            Y(:,2)=localSquareOutput(A,Kdc,inputPeak,t,T); % Exact periodic square.
            % Triangle Fourier series: odd harmonics with alternating signs.
            for h=1:numHarmonics % Truncated steady-state harmonic sum.
                n=2*h-1;         % n = 1, 3, 5 ... odd harmonics.
                coeff=(8/pi^2)*(-1)^(h-1)/n^2; % Triangle Fourier weight.
                Hn=(G+1i*(2*pi*f*n)*C)\B; % Response at harmonic n*f.
                Y(:,3)=Y(:,3)+inputPeak*coeff*imag(Hn(1)*exp(1i*n*theta));
            end
            % RMS is evaluated by TRAPEZOIDAL time integration, not mean.
            % Nonuniform mesh prevents underweighting narrow transitions.
            for k=1:3
                inRms=sqrt(trapz(t,U(:,k).^2)/T); % Independent input RMS.
                outRms=sqrt(trapz(t,Y(:,k).^2)/T); % Independent output RMS.
                gainRms=outRms/max(inRms,eps); % True per-waveform ratio.
                denom=trapz(t,U(:,k).^2); % Best-fit gain denominator.
                alpha=trapz(t,U(:,k).*Y(:,k))/max(denom,eps);
                errorPct=100*sqrt(trapz(t,(Y(:,k)-alpha*U(:,k)).^2)/T)/max(outRms,eps);
                peakOut=max(abs(Y(:,k))); % Largest sampled AC magnitude.
                meanOut=trapz(t,Y(:,k))/T; % Mean output over the period.
                rows(end+1,:)={D.name,capLabel,f,waveNames{k},...
                    inputPeak*1e3,gainRms,peakOut*1e3,meanOut*1e3,...
                    alpha,errorPct}; %#ok<SAGROW>
                subplot(3,4,(k-1)*4+fi); % Waveform row, frequency column.
                plot(t/T,U(:,k)*1e3,'--','LineWidth',0.9); hold on;
                plot(t/T,Y(:,k)*1e3,'LineWidth',1.0); grid on;
                title(sprintf('%s at %g kHz',waveNames{k},f/1e3));
                if fi==1,ylabel('AC [mV]');end
                if k==3,xlabel('Time [periods]');end
                if k==1 && fi==1, legend('Vin','Vout','Location','best');end
            end
            fprintf('%8.0f Hz: |Hsin| %.7g, phase %+8.3f deg\n',...
                f,abs(H(fi)),angle(H(fi))*180/pi); % Sine Bode metrics.
        end
        saveas(wf,['AHDS_FVF_V3_BSS84_' tag '_Waveforms.png']); close(wf);
    end
end

%% H. Combined data tables: labels distinguish assumptions from measurements.
Tmetrics=cell2table(rows,'VariableNames',{'MOSFET','CgdCase','Frequency_Hz',...
    'Waveform','InputPeak_mV','RMS_Gain','OutputPeak_mV','OutputMean_mV',...
    'BestFitGain','ShapeError_percent'}); % Each frequency / waveform.
Tedges=cell2table(edgeRows,'VariableNames',{'MOSFET','CgdCase',...
    'RiseTime_10_90_ns','FallTime_90_10_ns','Delay50_ns',...
    'Overshoot_percent','Undershoot_percent','Settling2pct_ns'});
Tfreq=cell2table(frequencyRows,'VariableNames',{'MOSFET','CgdCase',...
    'Frequency_Hz','GainMagnitude','Gain_dB','Phase_deg'});
disp('=== WAVEFORM METRICS (illustrative models) ==='); disp(Tmetrics);
disp('=== STEP METRICS (ideal linear response) ==='); disp(Tedges);
disp('=== CLOSED-LOOP TRANSFER H(jw), NOT LOOP GAIN ==='); disp(Tfreq);
writetable(Tmetrics,'AHDS_FVF_V3_BSS84_WaveformSummary.csv'); % Export comparison.
writetable(Tedges,'AHDS_FVF_V3_BSS84_EdgeSummary.csv'); % Export front metrics.
writetable(Tfreq,'AHDS_FVF_V3_BSS84_FrequencySummary.csv'); % Export Bode data.

%% I. Bode magnitude / phase comparison of ALL selected models.
caseNames={'WithCgd','NoCgd'}; % Valid cell indexing for MATLAB.
bf=figure('Color','w','Name','AHDS FVF V3 frequency comparison');
subplot(2,1,1); hold on; grid on; % Magnitude axis.
for d=1:numel(devices)
 for c=1:2
  mask=strcmp(Tfreq.MOSFET,devices(d).name)&strcmp(Tfreq.CgdCase,...
      caseNames{c}); %#ok<CCAT> % Label selection.
  semilogx(Tfreq.Frequency_Hz(mask),Tfreq.Gain_dB(mask),'-o',...
      'DisplayName',[devices(d).tag ' ' caseNames{c}]);
 end
end
xlabel('Frequency [Hz]'); ylabel('|H| [dB]'); title('Closed-loop gain — NOT loop gain');legend('Location','best');
subplot(2,1,2);hold on;grid on; % Phase axis.
for d=1:numel(devices)
 for c=1:2
  mask=strcmp(Tfreq.MOSFET,devices(d).name)&strcmp(Tfreq.CgdCase,...
      caseNames{c}); %#ok<CCAT>
  semilogx(Tfreq.Frequency_Hz(mask),Tfreq.Phase_deg(mask),'-o',...
      'DisplayName',[devices(d).tag ' ' caseNames{c}]);
 end
end
xlabel('Frequency [Hz]');ylabel('Phase [deg]');legend('Location','best');
saveas(bf,'AHDS_FVF_V3_BSS84_BodeComparison.png');
fprintf('\nV3 complete: three CSV tables, edge/waveform figures, Bode figure.\n');
fprintf('CAUTION: Cgd=0 is a sensitivity experiment; components not DC-validated.\n');

%% LOCAL FUNCTIONS — BASE MATLAB ONLY, used by both standalone programs.
function y=localStepOutput(A,Kdc,peak,t)
% Exact response after input step -peak to +peak from a settled initial state.
[V,L]=eig(A);                % Diagonalize 2-state linear system.
coef=V\(-2*peak*Kdc);       % Initial offset in eigenvector coordinates.
weights=V(1,:).*coef.';     % Output projection of each eigenmode.
y=peak*Kdc(1)+real(exp(t*diag(L).')*weights.'); % Output in volts.
end

function tCross=localCross(t,y,level)
% First upward crossing of a normalized step at a fractional target.
idx=find(y>=level,1,'first'); % Detect first threshold crossing.
if isempty(idx),tCross=NaN;return;end % Mark out-of-range condition.
if idx==1,tCross=t(1);return;end % Crossing already present at start.
tCross=t(idx-1)+(t(idx)-t(idx-1))*(level-y(idx-1))/...
    (y(idx)-y(idx-1));       % Linear sub-sample interpolation.
end

function y=localSquareOutput(A,Kdc,peak,t,T)
% Exact settled periodic square response, switching +peak / -peak each T/2.
I=eye(2);                   % Identity for the 2-state system.
P=expm(A*T/2);              % Exact half-period transition.
xp=peak*Kdc;               % Equilibrium for high plateau.
xm=-peak*Kdc;              % Equilibrium for low plateau.
x0=(I-P*P)\(P*(I-P)*xp+(I-P)*xm); % State immediately after rising edge.
x1=xp+P*(x0-xp);           % State immediately after falling edge.
[V,L]=eig(A);               % Reuse modal solution for both half-cycles.
vals=diag(L).';            % Row vector of modal decay rates.
y=zeros(size(t));          % Allocate output.
i1=t<T/2;                  % First half-cycle is HIGH.
c1=V\(x0-xp);               % Eigenmode initial amplitudes, high half.
w1=V(1,:).*c1.';           % Weights projected to Vout.
y(i1)=xp(1)+real(exp(t(i1)*vals)*w1.'); % High-half response.
i2=~i1;                   % Second half-cycle is LOW.
c2=V\(x1-xm);               % Eigenmode initial amplitudes, low half.
w2=V(1,:).*c2.';           % Weights projected to Vout.
y(i2)=xm(1)+real(exp((t(i2)-T/2)*vals)*w2.'); % Low-half response.
end
