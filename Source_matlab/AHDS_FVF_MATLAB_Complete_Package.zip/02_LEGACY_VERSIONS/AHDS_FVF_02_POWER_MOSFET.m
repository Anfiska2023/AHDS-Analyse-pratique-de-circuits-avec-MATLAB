% AHDS MATLAB-01 — FVF TWO-NODE SMALL-SIGNAL TRANSIENT STUDY
% Design once. Reuse forever. | ahds@engineer.com
% MATLAB Online compatible; base MATLAB only (no extra toolboxes).
%
% IMPORTANT ENGINEERING LIMITATION:
% This is a *linearized* two-node FVF circuit around an assumed DC bias.
% The signal u(t) is a SMALL-SIGNAL DEVIATION of Vin around Vbias,
% NOT an absolute 0–5 V gate drive. Square waves are ideal test signals.
% gm and ro are illustrative bias-dependent inputs, not verified datasheet
% values; Crss is an approximate small-signal Cgd at one bias condition.
% This model does NOT establish the DC operating point or safe VGS/VDS,
% large-signal clipping, nonlinear capacitors, or hardware-validated behavior.
% The two-state characteristic poles are CLOSED-LOOP poles, NOT a rigorous
% return-ratio loop gain measured at the MP gate. Do not call these loop poles.
%
% CIRCUIT: MP=P-MOS high-side (source AC-ground at VDD, gate=F,
% drain=Vout); MF=P-MOS follower device (source=Vout, gate=Vin,
% drain=F); CC from F to GND, Cout from Vout to GND,
% MP Cgd between F and Vout, bias current-source roB from F to GND.
% The MF model includes gmF and roF; MP model includes gmP and roP.
clear; clc; close all;

% --- SETUP: edit only this input block for first MATLAB Online runs ---
VDD = 12;                 % DC supply volts; NOT injected into linear AC model
Vbias = 6;                % Indicative gate DC bias, not independently solved
inputPeak = 0.05;         % Small-signal input excursion: +/- 50 mV
frequencyHz = 1e3;       % Base frequency for all three waveforms
cycles = 5;              % Simulate five periods for each case
pointsPerPeriod = 500;   % Time-grid resolution
Cc = 100e-12;             % F-node compensation capacitor [F]
Cout = 5e-12;             % Output capacitor [F]
roB = 200e3;              % Bias source incremental output resistance [ohm]

% Power-device study: compare two alternative P-channel MOSFETs
% in the MP position, NEVER simultaneously installed as parallel devices.
% CgdP values are illustrative placeholders; datasheet Crss is strongly
% dependent on bias voltage and vendor variant. Replace with bias-matched
% curves before quantitative claims. gmP / roP are NOT datasheet-verified.
devices = struct('name',{'IRF9540N (power)','IRF4905 (power)'}, ...
    'gmP',{0.080,0.150}, 'roP',{20e3,12e3}, 'gmF',{5e-3,5e-3}, ...
    'roF',{100e3,100e3}, 'CgdP',{240e-12,500e-12});
% NOTE: Large gmP values with unchanged MF and compensation bias are merely
% illustrative; a real power MOSFET requires a new DC bias and thermal review.

% Prepare all three requested shapes on an identical time grid.
waveNames = {'Sine','Square','Triangle'};
t = linspace(0,cycles/frequencyHz,cycles*pointsPerPeriod+1)';
w = 2*pi*frequencyHz;

% Three zero-mean signals of equal 50-mV peak amplitude.
U = zeros(numel(t),3);
U(:,1) = inputPeak*sin(w*t);                   % Sine
U(:,2) = inputPeak*(2*(sin(w*t)>=0)-1);      % Square, +/- peak
U(:,3) = inputPeak*(2/pi)*asin(sin(w*t));  % Triangle, +/- peak
% The physical input would be Vbias+U, but valid operation is not verified.

results = cell(numel(devices)*3,8);
ri = 0;
for d=1:numel(devices)
    p=devices(d);
    gop = 1/p.roP;                            % MP output conductance
    gof = 1/p.roF;                            % MF output conductance
    gob = 1/roB;                              % Bias source conductance

    % KCL: C*[dvout/dt; dF/dt] + G*[vout; vF] = B*vin.
    % MP Cgd is between nodes Vout and F: cross-capacitance is negative.
    C = [Cout+p.CgdP, -p.CgdP; -p.CgdP, Cc+p.CgdP];
    % G includes negative-feedback transconductances of the two P-MOSFETs.
    G = [gop+p.gmF+gof, p.gmP-gof; -(p.gmF+gof), gof+gob];
    % A small-signal Vin perturbation acts through MF gm into both nodes.
    B = [p.gmF; -p.gmF];
    A = -(C\G);                              % State matrix [1/s]
    Bin = C\B;                               % Input matrix [1/s]
    eigP = eig(A);                             % Closed-loop natural poles

    % If unstable, signal output will not represent a valid stable response.
    if any(real(eigP)>=0)
        warning('%s: unstable small-signal linear model. Review bias.',p.name);
    end
    fprintf('\n=== %s ===\n',p.name);
    fprintf('Closed-loop poles (Hz): %.6g%+.6gj ; %.6g%+.6gj\n', ...
        real(eigP(1))/(2*pi),imag(eigP(1))/(2*pi), ...
        real(eigP(2))/(2*pi),imag(eigP(2))/(2*pi));

    % Exact zero-order-hold time step on the chosen sample grid.
    % Unlike forward Euler, expm remains numerically reliable for stiff A.
    dt=t(2)-t(1);
    E = expm([A Bin; 0 0 0]*dt);
    Phi = E(1:2,1:2);                          % State transition
    Gamma = E(1:2,3);                         % Held-input contribution

    fig = figure('Color','w','Name',p.name);
    for k=1:3
        % Initial state x=0 means starting at assumed equilibrium.
        x=zeros(2,numel(t));
        for n=1:numel(t)-1
            x(:,n+1)=Phi*x(:,n)+Gamma*U(n,k);
        end
        y=x(1,:)';                            % Output AC deviation
        % Report on the last full period to avoid startup effects.
        inds=(numel(t)-pointsPerPeriod):numel(t);
        uu=U(inds,k);
        yy=y(inds);
        inRms=sqrt(mean(uu.^2));
        outRms=sqrt(mean(yy.^2));
        gainRms=outRms/max(inRms,eps);
        peakOutput=max(abs(yy));
        dcOutput=mean(yy);
        % A numerical error proxy for waveform tracking after scaling.
        % This is a SHAPE metric, not a distortion/THD claim.
        if (uu'*uu)>eps
            scale=(uu'*yy)/(uu'*uu);
            shapeErr=sqrt(mean((yy-scale*uu).^2))/max(outRms,eps)*100;
        else
            shapeErr=NaN;
        end
        ri=ri+1;
        results(ri,:)={p.name,waveNames{k},frequencyHz,inputPeak*1e3, ...
            gainRms,peakOutput*1e3,dcOutput*1e3,shapeErr};
        fprintf('%-8s RMS gain = %10.5g | Vout peak = %9.4g mV | shape error = %.4g %%\n', ...
            waveNames{k},gainRms,peakOutput*1e3,shapeErr);
        subplot(3,1,k);
        plot(t*1e3,U(:,k)*1e3,'--','LineWidth',1.1); hold on;
        plot(t*1e3,y*1e3,'LineWidth',1.2); grid on;
        ylabel('AC [mV]');
        title([p.name ' — ' waveNames{k}]);
        legend('Vin deviation','Vout deviation','Location','best');
        if k==3, xlabel('Time [ms]'); end
    end
    % Save figures and results in the current MATLAB Online folder.
    safeName=regexprep(p.name,'[^a-zA-Z0-9]','_');
    saveas(fig,['AHDS_FVF_' safeName '.png']);
end

T=cell2table(results,'VariableNames', ...
    {'MOSFET','Waveform','Frequency_Hz','InputPeak_mV', ...
     'RMS_Gain','OutputPeak_mV','OutputMean_mV','ShapeError_percent'});
disp(T);
writetable(T,'AHDS_FVF_results.csv');

% Interpretation guidance:
% 1) Compare 3 waveforms within a MOSFET under identical input conditions.
% 2) Compare MP device alternatives without claiming datasheet accuracy.
% 3) The linear model has NO clipping, nonlinear Cgd, threshold or MOS power.
% 4) For publication: obtain vendor SPICE models and solve real DC bias first.
