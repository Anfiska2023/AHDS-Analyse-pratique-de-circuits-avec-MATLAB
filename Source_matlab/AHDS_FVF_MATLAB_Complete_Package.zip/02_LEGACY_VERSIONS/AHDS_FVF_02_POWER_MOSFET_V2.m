% AHDS MATLAB-02 | POWER P-MOSFETs | VERSION 2 — TRANSIENT AND EDGE METRICS
% Anissoff Hardware Development System | Design once. Reuse forever.
% Contact: ahds@engineer.com
% MATLAB Online: BASE MATLAB ONLY. No Control System Toolbox required.
%
% IMPORTANT: The FVF is linearized about an ASSUMED DC operating point.
% gm, ro and Cgd are illustrative, NOT fitted vendor model parameters.
% Power devices need independently designed DC bias and thermal validation.
% IRF9540N and IRF4905 are ALTERNATIVES for MP, not used together.
% AC perturbations +/-50 mV are NOT an absolute gate swing from 0 to 5 V.
% This code does NOT validate DC bias, VGS rating or any physical hardware.
% Poles below are CLOSED-LOOP state poles, NOT open-loop return-ratio poles.
%
% Topology: MP (P-MOS) source=VDD (AC ground), gate=F, drain=Vout;
% MF (P-MOS) source=Vout, gate=Vin, drain=F; Cc from F to GND;
% Cout from Vout to GND; CgdP between F and Vout; roB F-to-GND.
clear; clc; close all;

%% 1) User-adjustable simulation parameters
VDD = 12;                    % [V] DC supply, NOT in the AC equations
Vbias = 6;                   % [V] assumed bias reference; not DC-verified
inputPeak = 50e-3;           % [V] AC peak (+/-50 mV)
freqHz = 1e3;                % [Hz] three waveform fundamental frequency
cycles = 5;                 % [-] simulated periods
pointsPerPeriod = 2000;     % [-] full-record plotting resolution
Cc = 100e-12;               % [F] F node to ground
Cout = 5e-12;               % [F] Vout node to ground
roB = 200e3;                % [ohm] incremental bias-source resistance

%% 2) Illustrative POWER MOSFET parameter sets (NOT extracted from SPICE)
% Each entry substitutes MP only; MF stays the SAME assumed small-signal FVF.
% Transconductance/output resistance/capacitance must later be extracted at
% a real DC bias point from a chosen manufacturer's MOSFET model.
devices = struct('name',{'IRF9540N (power)','IRF4905 (power)'}, ...
    'tag',{'IRF9540N','IRF4905'}, ...
    'gmP',{80e-3,150e-3}, ...           % [S] illustrative only
    'roP',{20e3,12e3}, ...              % [ohm] illustrative only
    'CgdP',{240e-12,500e-12});         % [F] placeholders, voltage dependent

% The follower transistor MF is held fixed for a controlled model comparison.
gmF = 5e-3;                           % [S] assumed MF transconductance
roF = 100e3;                          % [ohm] assumed MF output resistance
allResults = table();                 % Collect waveform tables across devices
allEdges = table();                   % Collect edge metrics across devices

for d = 1:numel(devices)              % Test one MP device at a time
    deviceName = devices(d).name;      % Human-readable device name
    deviceTag = devices(d).tag;        % Filename-safe short identifier
    gmP = devices(d).gmP;              % Selected MP gm
    roP = devices(d).roP;              % Selected MP ro
    CgdP = devices(d).CgdP;            % Selected MP Cgd
    fileBase = ['AHDS_FVF_POWER_V2_' deviceTag]; % Unique filenames

%% 3) Build the TWO-NODE linear differential model C*x' + G*x = B*u
% State x = [vout_ac ; vF_ac]. Input u = vin_ac. DC offsets are excluded.
gop = 1/roP;                 % [S] MP small-signal output conductance
gof = 1/roF;                 % [S] MF small-signal output conductance
gob = 1/roB;                 % [S] bias-source conductance
Cmat = [Cout+CgdP, -CgdP; -CgdP, Cc+CgdP]; % [F] node capacitances
Gmat = [gop+gmF+gof, gmP-gof; -(gmF+gof), gof+gob]; % [S]
Bvec = [gmF; -gmF];          % [S] input-controlled nodal currents
A = -(Cmat\Gmat);           % [1/s] state transition generator
Bstate = Cmat\Bvec;         % [1/s] input coefficient
polesHz = eig(A)/(2*pi);    % [Hz] characteristic closed-loop poles
Kdc = Gmat\Bvec;            % [-] static input-to-node gains

fprintf('\n=== AHDS FVF-02 Version 2: %s ===\n',deviceName);
fprintf('Supply %.3g V, assumed Vin DC bias %.3g V; AC peak %.3f mV\n',VDD,Vbias,1e3*inputPeak);
fprintf('Closed-loop poles, Hz: %.7g%+.7gj ; %.7g%+.7gj\n', ...
    real(polesHz(1)),imag(polesHz(1)),real(polesHz(2)),imag(polesHz(2)));
fprintf('DC incremental Vout/Vin: %.9g\n',Kdc(1));
if any(real(eig(A)) >= 0)
    error('The selected small-signal model has an unstable closed-loop pole.');
end

%% 4) Time grid, with square edges placed exactly at sample boundaries
P = 1/freqHz;                % [s] fundamental period
dt = P/pointsPerPeriod;      % [s] regular output grid step
N = cycles*pointsPerPeriod;  % [-] number of sample intervals
t = (0:N)'*dt;              % [s] column vector including last endpoint
w = 2*pi*freqHz;            % [rad/s] angular frequency
U = zeros(numel(t),3);      % [V] one column per waveform
U(:,1) = inputPeak*sin(w*t);                  % sine
U(:,2) = inputPeak*(2*(mod(floor(t/(P/2)),2)==0)-1); % square, starts high
U(:,3) = inputPeak*(2/pi)*asin(sin(w*t));   % triangle
waveNames = {'Sine','Square','Triangle'};     % labels and CSV entries

%% 5) Exact zero-order-hold discretization (one matrix exponential)
% With time step dt, the state obeys x(n+1)=Phi*x(n)+Gamma*u(n).
% The ideal square-wave transition is aligned with the time grid; unlike
% numerical Euler stepping this does not distort the intrinsic pole rates.
aug = [A Bstate; zeros(1,3)];               % 3x3 augmented generator
Z = expm(aug*dt);                            % exact ZOH discretization
Phi = Z(1:2,1:2);                            % state transition
Gamma = Z(1:2,3);                            % input accumulation
Y = zeros(numel(t),3);                      % all three output signals
Tresults = cell(3,9);                       % table with per-waveform metrics

%% 6) Simulate all three waveforms SEPARATELY
for k = 1:3
    x = zeros(2,1);                          % AC equilibrium at t=0
    for n = 1:N
        Y(n,k) = x(1);                        % store output BEFORE step
        x = Phi*x+Gamma*U(n,k);               % propagate sample k
    end
    Y(end,k) = x(1);                         % save final output sample

    % Use exactly ONE full period at end, omit duplicate final endpoint.
    idx = (N-pointsPerPeriod+1):N;           % same window for each waveform
    uu = U(idx,k);                           % [V] windowed input
    yy = Y(idx,k);                           % [V] windowed output
    inRms = sqrt(mean(uu.^2));               % actual RMS of THIS waveform
    outRms = sqrt(mean(yy.^2));              % actual output RMS
    gainRms = outRms/max(inRms,eps);         % per-waveform RMS ratio
    outPk = max(abs(yy));                    % [V] peak absolute output
    outMean = mean(yy);                      % [V] mean offset
    % The least-squares instantaneous scale is recomputed per waveform.
    alpha = (uu'*yy)/max(uu'*uu,eps);        % [-] best-fitting gain
    shapeError = 100*sqrt(mean((yy-alpha*uu).^2))/max(outRms,eps);
    Tresults(k,:) = {deviceName,waveNames{k},freqHz,inputPeak*1e3, ...
        gainRms,outPk*1e3,outMean*1e3,alpha,shapeError};
    fprintf('%-8s: RMS gain %.7f | Peak %.4f mV | Shape error %.4f %%\n', ...
        waveNames{k},gainRms,1e3*outPk,shapeError);
end

%% 7) Full-record figure with correct individual results
fig1 = figure('Color','w','Name',[deviceTag ' V2 - all three waveforms']);
for k=1:3
    subplot(3,1,k);                          % separate waveform axes
    plot(t*1e3,U(:,k)*1e3,'--','LineWidth',1); hold on;
    plot(t*1e3,Y(:,k)*1e3,'LineWidth',1.1); grid on;
    ylabel('AC [mV]');                       % perturbation, not DC output
    title([deviceName ' — ' waveNames{k}]);   % descriptive title
    legend('Vin (AC)','Vout (AC)','Location','best');
    if k==3, xlabel('Time [ms]'); end
end
saveas(fig1,[fileBase '_Waveforms.png']);

%% 8) HIGH-RESOLUTION ideal edge from settled LOW to HIGH input
% This is an EXACT analytical linear-step response of the SAME state model.
% No huge (nanosecond-step for milliseconds) simulation grid is needed.
% Before t=0 the system is assumed to have settled with u=-inputPeak.
% At t=0 the input switches instantaneously to +inputPeak.
uBefore = -inputPeak;                        % [V] low plateau
uAfter = +inputPeak;                         % [V] high plateau
xBefore = Kdc*uBefore;                       % both nodes' initial states
xAfter = Kdc*uAfter;                         % both nodes' final states
xDelta = xBefore-xAfter;                     % decaying transient state
pMag = min(abs(real(eig(A))));               % [1/s] slowest stable rate
tauSlow = 1/pMag;                            % [s] slowest decay time
edgeDuration = max(12*tauSlow,1e-9);        % [s] >=12 slow time constants
te = linspace(0,edgeDuration,5001)';        % [s] zoomed edge time axis
ye = zeros(size(te));                        % [V] output across the edge
for n=1:numel(te)
    xe = xAfter+expm(A*te(n))*xDelta;         % exact analytic response
    ye(n) = xe(1);                           % extract Vout deviation
end
v0 = xBefore(1);                            % [V] initial output plateau
vf = xAfter(1);                             % [V] final output plateau
stepSize = vf-v0;                            % [V] signed output step
if abs(stepSize) < eps
    error('No measurable output transition at the selected bias.');
end
normalized = (ye-v0)/stepSize;              % rise normalized to 0...1

% Determine FIRST crossings by interpolation, robust to mild overshoot.
t10 = firstCrossing(te,normalized,0.10);    % [s] initial 10%% crossing
t50 = firstCrossing(te,normalized,0.50);    % [s] input-to-output 50%% delay
t90 = firstCrossing(te,normalized,0.90);    % [s] first 90%% crossing
riseTime = t90-t10;                          % [s] 10-90 %% rise time
overshoot = max(0,(max(normalized)-1)*100); % [%%] beyond final plateau
undershoot = max(0,-min(normalized)*100);   % [%%] below initial plateau

% 2%% settling: last excursion outside final-value tolerance.
tolerance = 0.02;                            % [-] settling tolerance
lastBad = find(abs(normalized-1)>tolerance,1,'last');
if isempty(lastBad)
    settlingTime = 0;                        % step is immediately settled
elseif lastBad == numel(te)
    settlingTime = NaN;                      % not settled in zoom window
else
    settlingTime = te(lastBad+1);            % [s] final entry into band
end

% Repeat opposite step to report fall time and negative-edge excursions.
% For a LINEAR, time-invariant model the normalized fall edge is identical.
% The raw falling output decreases, but its normalized progression is 0->1.
fallTime = riseTime;                         % [s] symmetry of LTI model
fprintf('\n--- Ideal low->high square-wave edge (high-resolution) ---\n');
fprintf('Rise 10-90%%:       %.6g ns\n',1e9*riseTime);
fprintf('Fall 90-10%%:      %.6g ns [LTI symmetry]\n',1e9*fallTime);
fprintf('50%% propagation:  %.6g ns\n',1e9*t50);
fprintf('Overshoot:        %.6g %%\n',overshoot);
fprintf('Undershoot:       %.6g %%\n',undershoot);
fprintf('Settling time 2%%: %.6g ns\n',1e9*settlingTime);

%% 9) Extra figure with magnified input step and output response
fig2=figure('Color','w','Name',[deviceTag ' V2 - high-resolution edge']);
plot(te*1e9,1e3*ye,'LineWidth',1.6); hold on; % [ns], [mV]
plot([te(1) te(end)]*1e9,[uAfter uAfter]*1e3,'--','LineWidth',1.1);
plot([te(1) te(end)]*1e9,[vf vf]*1e3,':','LineWidth',1);
xlabel('Time after rising edge [ns]');
ylabel('AC voltage [mV]');
title([deviceTag ' FVF: linear small-signal square-wave edge, zoomed']);
legend('Vout','Vin ideal step','Final Vout','Location','best');
grid on;
saveas(fig2,[fileBase '_Edge_Zoom.png']);

%% 10) Export per-waveform comparison and independent edge metrics
T = cell2table(Tresults,'VariableNames', ...
    {'MOSFET','Waveform','Frequency_Hz','InputPeak_mV', ...
    'RMS_Gain','OutputPeak_mV','OutputMean_mV', ...
    'InstantaneousBestFitGain','ShapeError_percent'});
disp(T);
writetable(T,[fileBase '_Results.csv']);
allResults = [allResults;T];           % Append this device's measurements

EdgeMetrics = table(riseTime*1e9,fallTime*1e9,t50*1e9, ...
    overshoot,undershoot,settlingTime*1e9, ...
    'VariableNames',{'RiseTime_10_90_ns','FallTime_90_10_ns', ...
    'Delay50_ns','Overshoot_percent','Undershoot_percent','Settling2pct_ns'});
disp(EdgeMetrics);
writetable(EdgeMetrics,[fileBase '_Edge_Metrics.csv']);
allEdges = [allEdges; addvars(EdgeMetrics,{deviceName},'Before',1, ...
    'NewVariableNames','MOSFET')];     % Store device-labelled edge row

%% 11) Interpretation and important publication limitations
fprintf('\nDevice files saved: 2 PNG figures + 2 CSV tables.\n');
fprintf('The square edge was resolved analytically at nanosecond scales.\n');
fprintf('RMS gain is independently recomputed for Sine, Square and Triangle.\n');
fprintf('Shape Error is NOT THD. Closed-loop poles are NOT loop-gain poles.\n');
fprintf('For actual power MOSFETs: solve DC bias and use voltage-dependent caps.\n');

end % Device loop: all three waveforms and edge response per MOSFET.

%% 12) Consolidated cross-device comparison tables
writetable(allResults,'AHDS_FVF_POWER_V2_All_Waveforms.csv');
writetable(allEdges,'AHDS_FVF_POWER_V2_All_Edges.csv');
fprintf('\n=== SUMMARY: ALL DEVICES, ALL THREE WAVEFORMS ===\n');
disp(allResults);
fprintf('\n=== EDGE METRICS BY DEVICE ===\n');
disp(allEdges);
fprintf('Study complete: 4 PNG files, 4 device CSV files, 2 comparison CSV files.\n');
fprintf('No physical device performance is established by these placeholder models.\n');

%% Local helper: first interpolated crossing of a normalized edge
function tx = firstCrossing(time,level,threshold)
    % Locate FIRST upward crossing through requested normalized threshold.
    % This can be used even when the final response overshoots or rings.
    j=find(level(1:end-1)<threshold & level(2:end)>=threshold,1,'first');
    if isempty(j)
        tx=NaN;                                % crossing not observed
        return;
    end
    fraction=(threshold-level(j))/(level(j+1)-level(j));
    tx=time(j)+fraction*(time(j+1)-time(j)); % linear sub-sample interpolation
end
