AHDS — Anissoff Hardware Development System
MATLAB FVF STUDY: SOURCE CODE & USER GUIDE
Design once. Reuse forever.
Contact: ahds@engineer.com

PROJECT OVERVIEW
This archive contains the four FINAL analysis scripts used in the comparative
Flipped Voltage Follower (FVF) study, plus earlier revisions for traceability.
Run the four FINAL programs; the LEGACY folder is for reference only.

MATLAB ONLINE QUICK START
1. Open https://matlab.mathworks.com/ and sign in to MathWorks.
2. Download and unzip this package on your computer.
3. Upload the four *.m files from 01_FINAL_SCRIPTS to MATLAB Drive.
4. In MATLAB Online Current Folder, double-click a script, then click Run.
5. Inspect figures, Command Window tables, PNG graphics and CSV results.
6. Run scripts one at a time. Save/copy generated results before a later run
   if you want to retain all outputs. The scripts use illustrative parameters.

01_FINAL_SCRIPTS
1. FVF-01_BSS84_V3_1.m — SMALL-SIGNAL BSS84
   Four frequencies: 1 kHz, 10 kHz, 100 kHz, 1 MHz.
   Three waveforms: sine, square, triangle; with and without Cgd.
   Five MATLAB figures expected: four waveform/edge figures and one
   closed-loop frequency-comparison figure. Generates CSV tables/PNG.
2. FVF-02_Power_V3_1.m — POWER MOSFET IRF9540N and IRF4905
   Same four frequencies, three waveforms, and Cgd comparison.
   Nine MATLAB figures expected (4 per MOSFET + 1 comparison).
   Generates comparative CSV tables and PNG graphics.
3. FVF-03_Loop_Gain.m — gmP SOURCE-PATH RETURN RATIO
   All three P-channel MOSFET models; loop poles, loop zeros,
   gain/phase crossover metrics and Bode plots. Seven figures expected.
   NOT identical to physical loaded gate-break measurement.
4. FVF-04_Gate_Break.m — GATE-BREAK COMPARISON
   All three MOSFET models; compares open-gate voltage return and
   gmP source-path return, with and without Cgd, and checks short
   reconstruction using a zero-volt series test source.
   Three figures expected and two CSV outputs.

02_LEGACY_VERSIONS
Earlier programs are included so readers can reproduce the development
history. V3.1 fixes the V3 figure-window reuse problem: generated figures
remain open rather than being closed and reused as Figure 1.

RESEARCH LIMITATIONS
- Models contain illustrative assumed gm, ro and Cgd values; DC bias
  consistency and voltage-dependent capacitances were not validated.
- These results are SOFTWARE SIMULATIONS, NOT physical MOSFET measurements.
- Closed-loop H(s), gmP source-path return ratio, and gate-voltage return
  are distinct analysis quantities. Do not interchange their phase margins.
- The 1 THz plotting sweep in FVF-03 extends beyond physically validated
  MOSFET model bandwidth; do not claim real-device RF performance.
- Shape Error is NOT total harmonic distortion (THD).
- All figure counts are expected from user-validated MATLAB Online runs;
  interface/version differences may affect window display.

For study context, consult the accompanying AHDS_FVF_Engineering_Report.docx.
